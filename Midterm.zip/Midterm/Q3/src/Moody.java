public abstract class Moody {

    public abstract String getMood();

    public abstract void expressFeelings();

    abstract void queryMood();

}
