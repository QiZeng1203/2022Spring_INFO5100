public class Main {

    public static void main(String[] args) {
	// write your code here
        // Q2
        /* The Difference between abstract class and interface
        1. a class can only extend one abstract class, but can implement multiply interface.
        2. abstract class can have data field, but interface cannot have data field.
        3. abstract class can have abstract or concrete method, but interface has only abstract method.
        4. abstract class can declare the constructor. but interface cannot declare the constructor
	 */
    }
}
