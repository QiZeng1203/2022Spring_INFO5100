public interface MathOperation {
        public int performOperation(int num1, int num2);
}
