public class Main {

    public static void main(String[] args) {
        // write your code here
        Student sample = new Student();
        Student s1 = new Student(sample);
        Student s2 = sample;
    }
}
